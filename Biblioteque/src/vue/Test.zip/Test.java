package vue;
import javax.swing.*;

public class Test extends javax.swing.JFrame {



    private JPanel contentPane;
    private JTextField Nom;
    private JTextField Prenom;
    private JLabel Sexe;
    private JButton Validation;
    private JButton Annuler;
    private JComboBox sexe;
}
